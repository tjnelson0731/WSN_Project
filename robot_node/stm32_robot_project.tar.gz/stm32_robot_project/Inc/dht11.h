#ifndef DHT11_H
#define DHT11_H

#include <stdint.h>

/**
 * DHT11 data pin: PA1
 *
 * Wiring:
 *   DHT11 pin 1 (VCC) → 3.3 V
 *   DHT11 pin 2 (DATA) → PA1 + 4.7 kΩ pull-up to 3.3 V
 *   DHT11 pin 4 (GND) → GND
 *
 * The internal STM32 pull-up (~40 kΩ) is enabled as a fallback, but an
 * external 4.7 kΩ resistor is strongly recommended for reliable reads.
 *
 * Minimum interval between reads: 1 second (DHT11 datasheet requirement).
 */

/* Raw 40-bit payload from the sensor */
typedef struct {
    uint8_t humidity_int;   /* relative humidity, integer part   [%RH] */
    uint8_t humidity_dec;   /* relative humidity, decimal (= 0 on DHT11) */
    uint8_t temp_int;       /* temperature, integer part          [°C]  */
    uint8_t temp_dec;       /* temperature, decimal (= 0 on DHT11)      */
    uint8_t checksum;       /* = sum of the four bytes above             */
} DHT11_Data;

typedef enum {
    DHT11_OK              = 0,
    DHT11_ERROR_TIMEOUT   = 1,  /* sensor did not respond in time   */
    DHT11_ERROR_CHECKSUM  = 2,  /* received data is corrupted       */
} DHT11_Status;

/**
 * DHT11_Init()
 *   Configure PA1 as push-pull output, drive high (bus idle).
 *   Call once at startup; wait ≥1 s before the first DHT11_Read().
 */
void DHT11_Init(void);

/**
 * DHT11_Read()
 *   Perform one full 1-wire transaction and populate *data.
 *   Takes ~22 ms to complete (18 ms start + ~4 ms data).
 *   Returns DHT11_OK on success.
 */
DHT11_Status DHT11_Read(DHT11_Data *data);

#endif /* DHT11_H */

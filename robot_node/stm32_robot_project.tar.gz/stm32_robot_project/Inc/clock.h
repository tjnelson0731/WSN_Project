#ifndef CLOCK_H
#define CLOCK_H

#include <stdint.h>

/**
 * SystemClock_Config()
 *
 * Configures the main PLL from HSI16:
 *
 *   VCO_in  = HSI16 / PLLM  = 16 / 1  =  16 MHz
 *   VCO_out = VCO_in * PLLN = 16 * 10 = 160 MHz
 *   SYSCLK  = VCO_out / PLLR = 160 / 2 =  80 MHz
 *
 *   HCLK  (AHB)  = 80 MHz  (prescaler /1)
 *   PCLK1 (APB1) = 80 MHz  (prescaler /1)  — USART2, TIM3
 *   PCLK2 (APB2) = 80 MHz  (prescaler /1)
 *
 * Flash latency is set to 4 WS (required for 64–80 MHz @ VDD 1.8–3.6 V).
 * Voltage scaling Range 1 is enforced (required for 80 MHz operation).
 */
void SystemClock_Config(void);

/**
 * DWT_Init()
 *
 * Enables the ARM DWT (Data Watchpoint and Trace) cycle counter.
 * DWT->CYCCNT increments every CPU clock cycle; at 80 MHz it wraps
 * after ~53.7 seconds.  All delay functions rely on this counter.
 */
void DWT_Init(void);

/**
 * delay_us() / delay_ms()
 *
 * Spin-wait delays using DWT->CYCCNT.  The subtraction (CYCCNT - start)
 * is unsigned 32-bit arithmetic, so wrap-around is handled correctly.
 *
 * Note: interrupts are not disabled; an ISR firing mid-delay extends it.
 * For short (<200 µs) timing-critical code (e.g. DHT11) disable IRQs if
 * needed, or keep all ISRs fast.
 */
void delay_us(uint32_t us);
void delay_ms(uint32_t ms);

#endif /* CLOCK_H */

/**
 * main.c — Robot main loop
 *
 * Peripherals initialised:
 *   PLL  → 80 MHz SYSCLK   (clock.c)
 *   DWT  → µs/ms delays    (clock.c)
 *   PA1  → DHT11 data line (dht11.c)
 *   TIM3 → motor PWM       (motor.c)
 *   PB0/1/4/5 → motor dir  (motor.c)
 *   USART2 PA2/3 → UART    (uart.c)
 *
 * Main loop:
 *   Every 2 seconds read the DHT11 and transmit a formatted string to
 *   the ESP32-C6 over UART2.  Example output:
 *     TEMP:23C HUM:55%\r\n
 *     TEMP:23C HUM:55%\r\n
 *     DHT11_ERR:CHECKSUM\r\n   ← on transient error, retry next cycle
 *
 * Motor control is a placeholder — replace the demo drive pattern with
 * your own steering algorithm (e.g. PID from encoder feedback).
 *
 * No stdlib is used for formatting — the send_u8() helper below converts
 * uint8_t to ASCII digits with no heap allocation.
 */

#include "stm32l4xx.h"
#include "clock.h"
#include "dht11.h"
#include "motor.h"
#include "uart.h"

/* ---------------------------------------------------------------------- */
/* Minimal numeric-to-UART helper (avoids pulling in printf/sprintf)       */
/* ---------------------------------------------------------------------- */

/**
 * send_u8 — transmit a uint8_t as 1–3 decimal ASCII digits.
 *
 * Algorithm: extract digits LSD-first into a small buffer, then replay
 * the buffer in reverse.  No leading zeros.
 *
 *   val = 0   → "0"
 *   val = 7   → "7"
 *   val = 42  → "42"
 *   val = 255 → "255"
 */
static void send_u8(uint8_t val)
{
    char buf[3];
    int  len = 0;

    if (val == 0) {
        UART_SendChar('0');
        return;
    }
    while (val > 0) {
        buf[len++] = (char)('0' + (val % 10));
        val = (uint8_t)(val / 10u);
    }
    /* digits are in buf[0..len-1] in reverse order */
    while (len--) {
        UART_SendChar(buf[len]);
    }
}

/* ---------------------------------------------------------------------- */
int main(void)
{
    /* ----- 1. Core clock: HSI16 → PLL → 80 MHz ----------------------- */
    SystemClock_Config();

    /* ----- 2. DWT cycle counter (needed by delay_us / DHT11 driver) --- */
    DWT_Init();

    /* ----- 3. Peripherals -------------------------------------------- */
    UART_Init(115200U);
    DHT11_Init();     /* also enables GPIOA clock */
    Motor_Init();     /* also enables GPIOA, GPIOB, TIM3 clocks */

    /* DHT11 requires ≥ 1 s after power-up before the first read.        */
    UART_SendString("BOOT\r\n");
    delay_ms(1500U);

    /* ----- 4. Demo motor pattern: drive forward at 70 % -------------- */
    Motor_SetLeft (MOTOR_FORWARD, 700U);
    Motor_SetRight(MOTOR_FORWARD, 700U);

    /* ----- 5. Main loop ----------------------------------------------- */
    DHT11_Data   sensor;
    DHT11_Status status;

    while (1) {
        /* Read sensor (takes ~22 ms internally) */
        status = DHT11_Read(&sensor);

        if (status == DHT11_OK) {
            /*
             * Transmit: "TEMP:XX HUM:XX\r\n"
             * DHT11 decimal bytes are always 0; omit them for clarity.
             */
            UART_SendString("TEMP:");
            send_u8(sensor.temp_int);
            UART_SendChar('C');
            UART_SendString(" HUM:");
            send_u8(sensor.humidity_int);
            UART_SendString("%\r\n");

        } else if (status == DHT11_ERROR_TIMEOUT) {
            UART_SendString("DHT11_ERR:TIMEOUT\r\n");

        } else {
            UART_SendString("DHT11_ERR:CHECKSUM\r\n");
        }

        /*
         * DHT11 minimum sampling interval: 1 s (datasheet requirement).
         * We wait 2 s to be conservative and leave headroom for the
         * ~22 ms already spent inside DHT11_Read().
         */
        delay_ms(2000U - 22U);
    }
}

/**
 * motor.c — Differential drive via SN754410 H-bridge
 *
 * Hardware assignments:
 *   Left  motor: EN ← PA6  (TIM3_CH1, AF2), IN_A ← PB0, IN_B ← PB1
 *   Right motor: EN ← PA7  (TIM3_CH2, AF2), IN_A ← PB4, IN_B ← PB5
 *
 * TIM3 PWM configuration:
 *   Source clock : PCLK1 = 80 MHz
 *   Prescaler    : PSC = 79  → timer clock = 80 MHz / 80 = 1 MHz
 *   Auto-reload  : ARR = 999 → f_PWM = 1 MHz / 1000 = 1 kHz
 *   CCR range    : 0 – 999   → 0 % – 99.9 % duty
 *                  CCR = 1000 (> ARR) → 100 % (always HIGH in PWM mode 1)
 *
 * PWM Mode 1 output (OC1M = 0110):
 *   CNT < CCR → output HIGH
 *   CNT ≥ CCR → output LOW
 *
 * SN754410 direction truth table (per motor):
 *   IN_A  IN_B  EN   Motor state
 *    H     L    PWM  Forward
 *    L     H    PWM  Backward
 *    H     H    H    Active brake (output shorted)
 *    X     X    L    Coast (output disabled)
 */

#include "stm32l4xx.h"
#include "motor.h"

/* ---- Pin definitions -------------------------------------------------- */
#define L_INA_PIN   0U   /* PB0 */
#define L_INB_PIN   1U   /* PB1 */
#define R_INA_PIN   4U   /* PB4 */
#define R_INB_PIN   5U   /* PB5 */

#define MAX_SPEED   1000U

/* ---------------------------------------------------------------------- */
void Motor_Init(void)
{
    /* Enable peripheral clocks */
    RCC->AHB2ENR  |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOBEN;
    RCC->APB1ENR1 |= RCC_APB1ENR1_TIM3EN;
    __DSB();

    /* ---- PA6 / PA7 : Alternate function 2 (TIM3_CH1 / TIM3_CH2) ----- */
    /* MODER: 10 = Alternate function */
    GPIOA->MODER = (GPIOA->MODER
                     & ~(GPIO_MODER_MODE6_Msk | GPIO_MODER_MODE7_Msk))
                 | (2UL << GPIO_MODER_MODE6_Pos)
                 | (2UL << GPIO_MODER_MODE7_Pos);

    /* AFRL: AF2 for PA6, PA7 (bits [27:24] and [31:28]) */
    GPIOA->AFR[0] = (GPIOA->AFR[0]
                      & ~(GPIO_AFRL_AFSEL6_Msk | GPIO_AFRL_AFSEL7_Msk))
                  | (2UL << GPIO_AFRL_AFSEL6_Pos)
                  | (2UL << GPIO_AFRL_AFSEL7_Pos);

    /* High-speed output for PWM signals */
    GPIOA->OSPEEDR |= (3UL << GPIO_OSPEEDR_OSPEED6_Pos)
                   |  (3UL << GPIO_OSPEEDR_OSPEED7_Pos);

    /* ---- PB0, PB1, PB4, PB5 : GPIO output (direction pins) ----------- */
    GPIOB->MODER = (GPIOB->MODER
                     & ~(  GPIO_MODER_MODE0_Msk | GPIO_MODER_MODE1_Msk
                          | GPIO_MODER_MODE4_Msk | GPIO_MODER_MODE5_Msk))
                 | (1UL << GPIO_MODER_MODE0_Pos)
                 | (1UL << GPIO_MODER_MODE1_Pos)
                 | (1UL << GPIO_MODER_MODE4_Pos)
                 | (1UL << GPIO_MODER_MODE5_Pos);

    /* Push-pull, no pull — clear OTYPER bits and PUPDR bits */
    GPIOB->OTYPER &= ~((1UL << L_INA_PIN) | (1UL << L_INB_PIN)
                      |(1UL << R_INA_PIN) | (1UL << R_INB_PIN));
    GPIOB->PUPDR  &= ~(  GPIO_PUPDR_PUPD0_Msk | GPIO_PUPDR_PUPD1_Msk
                        | GPIO_PUPDR_PUPD4_Msk | GPIO_PUPDR_PUPD5_Msk);

    /* All direction pins start LOW (motors coasting) */
    GPIOB->BRR = (1UL << L_INA_PIN) | (1UL << L_INB_PIN)
               | (1UL << R_INA_PIN) | (1UL << R_INB_PIN);

    /* ---- TIM3 : 1 kHz PWM on CH1 and CH2 ----------------------------- */
    TIM3->CR1  = 0;          /* disable while configuring                 */
    TIM3->PSC  = 79U;        /* 80 MHz / 80 = 1 MHz timer clock           */
    TIM3->ARR  = 999U;       /* 1 MHz / 1000 = 1 kHz                      */
    TIM3->CCR1 = 0U;         /* duty = 0 initially                        */
    TIM3->CCR2 = 0U;

    /*
     * CCMR1: configure CH1 and CH2 as PWM Mode 1
     *   OC1M[2:0] = 110 (bits [6:4]) → PWM mode 1
     *   OC1PE     = 1   (bit 3)      → CCR1 preload enable
     *   OC2M[2:0] = 110 (bits [14:12])
     *   OC2PE     = 1   (bit 11)
     * OC1M[3] (bit 16) and OC2M[3] (bit 24) remain 0 → standard PWM mode 1
     */
    TIM3->CCMR1 = (6UL << TIM_CCMR1_OC1M_Pos) | TIM_CCMR1_OC1PE
                | (6UL << TIM_CCMR1_OC2M_Pos) | TIM_CCMR1_OC2PE;

    /* CCER: enable CH1 and CH2 outputs, active HIGH */
    TIM3->CCER  = TIM_CCER_CC1E | TIM_CCER_CC2E;

    /* Auto-reload preload enable */
    TIM3->CR1   = TIM_CR1_ARPE;

    /* Generate an update event to transfer preload values into shadow regs */
    TIM3->EGR   = TIM_EGR_UG;
    TIM3->SR    = 0;    /* clear the update interrupt flag set by EGR=UG  */

    /* Start the timer */
    TIM3->CR1  |= TIM_CR1_CEN;
}

/* ---------------------------------------------------------------------- */
void Motor_SetLeft(Motor_Dir dir, uint16_t speed)
{
    if (speed > MAX_SPEED) speed = (uint16_t)MAX_SPEED;

    switch (dir) {
    case MOTOR_FORWARD:
        GPIOB->BSRR = (1UL << L_INA_PIN);          /* IN_A = H */
        GPIOB->BRR  = (1UL << L_INB_PIN);           /* IN_B = L */
        TIM3->CCR1  = speed;
        break;

    case MOTOR_BACKWARD:
        GPIOB->BRR  = (1UL << L_INA_PIN);           /* IN_A = L */
        GPIOB->BSRR = (1UL << L_INB_PIN);          /* IN_B = H */
        TIM3->CCR1  = speed;
        break;

    case MOTOR_BRAKE:
        /* Short both outputs: IN_A = H, IN_B = H, EN = 100 %           */
        GPIOB->BSRR = (1UL << L_INA_PIN) | (1UL << L_INB_PIN);
        TIM3->CCR1  = MAX_SPEED;
        break;

    case MOTOR_STOP:
    default:
        TIM3->CCR1  = 0;                             /* EN = 0 → coast   */
        GPIOB->BRR  = (1UL << L_INA_PIN) | (1UL << L_INB_PIN);
        break;
    }
}

void Motor_SetRight(Motor_Dir dir, uint16_t speed)
{
    if (speed > MAX_SPEED) speed = (uint16_t)MAX_SPEED;

    switch (dir) {
    case MOTOR_FORWARD:
        GPIOB->BSRR = (1UL << R_INA_PIN);
        GPIOB->BRR  = (1UL << R_INB_PIN);
        TIM3->CCR2  = speed;
        break;

    case MOTOR_BACKWARD:
        GPIOB->BRR  = (1UL << R_INA_PIN);
        GPIOB->BSRR = (1UL << R_INB_PIN);
        TIM3->CCR2  = speed;
        break;

    case MOTOR_BRAKE:
        GPIOB->BSRR = (1UL << R_INA_PIN) | (1UL << R_INB_PIN);
        TIM3->CCR2  = MAX_SPEED;
        break;

    case MOTOR_STOP:
    default:
        TIM3->CCR2  = 0;
        GPIOB->BRR  = (1UL << R_INA_PIN) | (1UL << R_INB_PIN);
        break;
    }
}

void Motor_Stop(void)
{
    TIM3->CCR1 = 0;
    TIM3->CCR2 = 0;
    GPIOB->BRR = (1UL << L_INA_PIN) | (1UL << L_INB_PIN)
               | (1UL << R_INA_PIN) | (1UL << R_INB_PIN);
}

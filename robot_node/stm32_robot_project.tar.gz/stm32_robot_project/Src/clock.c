/**
 * clock.c — System clock + DWT delays
 *
 * Target: 80 MHz from HSI16 via PLL on STM32L452RE
 *
 * PLL transfer function:
 *   f_VCO_in  = f_HSI16 / PLLM  =  16 MHz / 1  =  16 MHz
 *   f_VCO_out = f_VCO_in * PLLN =  16 MHz * 10  = 160 MHz
 *   f_PLLR    = f_VCO_out / PLLR = 160 MHz / 2  =  80 MHz  → SYSCLK
 *
 * Constraints (RM0394):
 *   f_VCO_in  ∈ [4, 16] MHz            → 16 MHz ✓
 *   f_VCO_out ∈ [64, 344] MHz          → 160 MHz ✓
 *   f_SYSCLK  ≤ 80 MHz (Range 1)       → 80 MHz ✓
 *   Flash latency: 4 WS for 64–80 MHz  (Table 9, RM0394)
 */

#include "stm32l4xx.h"
#include "clock.h"

/* ---------------------------------------------------------------------- */
void SystemClock_Config(void)
{
    /* 1. Voltage scaling: Range 1 allows up to 80 MHz.
     *    Default after reset is already Range 1, but set it explicitly
     *    in case we were in Range 2 (e.g. waking from low-power mode).   */
    RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;
    __DSB();
    PWR->CR1 = (PWR->CR1 & ~PWR_CR1_VOS_Msk) | (1UL << PWR_CR1_VOS_Pos);
    while (PWR->SR2 & PWR_SR2_VOSF);   /* wait for regulator */

    /* 2. Set flash latency BEFORE increasing the clock.
     *    Also enable instruction + data caches and prefetch buffer.      */
    FLASH->ACR = (FLASH->ACR & ~FLASH_ACR_LATENCY_Msk)
               | FLASH_ACR_LATENCY_4WS
               | FLASH_ACR_ICEN
               | FLASH_ACR_DCEN
               | FLASH_ACR_PRFTEN;
    /* Verify the latency was accepted (read-back required per RM0394)    */
    while ((FLASH->ACR & FLASH_ACR_LATENCY_Msk) != FLASH_ACR_LATENCY_4WS);

    /* 3. Enable HSI16 (16 MHz internal RC)                               */
    RCC->CR |= RCC_CR_HSION;
    while (!(RCC->CR & RCC_CR_HSIRDY));

    /* 4. Disable PLL before reconfiguring (required by hardware)         */
    RCC->CR &= ~RCC_CR_PLLON;
    while (RCC->CR & RCC_CR_PLLRDY);   /* wait for PLL to unlock         */

    /* 5. Configure PLL
     *    Bits [1:0]   PLLSRC = 10  → HSI16
     *    Bits [7:4]   PLLM   = 0   → /1  (0000 = divide-by-1)
     *    Bits [14:8]  PLLN   = 10  → ×10
     *    Bits [26:25] PLLR   = 00  → /2  (00 = divide-by-2)
     *    Bit  24      PLLREN = 1   → enable PLLR output to SYSCLK        */
    RCC->PLLCFGR =
        (2UL  << RCC_PLLCFGR_PLLSRC_Pos) |   /* HSI16             */
        (0UL  << RCC_PLLCFGR_PLLM_Pos)   |   /* M = 1             */
        (10UL << RCC_PLLCFGR_PLLN_Pos)   |   /* N = 10            */
        (0UL  << RCC_PLLCFGR_PLLR_Pos)   |   /* R = /2            */
        RCC_PLLCFGR_PLLREN;                   /* enable PLLR       */

    /* 6. Enable PLL and wait for lock                                    */
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));

    /* 7. AHB / APB prescalers = /1 (all buses run at 80 MHz)
     *    HPRE[7:4] = 0000 → /1
     *    PPRE1[10:8] = 000 → /1
     *    PPRE2[13:11] = 000 → /1                                         */
    RCC->CFGR &= ~( RCC_CFGR_HPRE_Msk
                  | RCC_CFGR_PPRE1_Msk
                  | RCC_CFGR_PPRE2_Msk );

    /* 8. Switch SYSCLK source to PLL
     *    SW[1:0] = 11 → PLL                                              */
    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW_Msk) | RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS_Msk) != RCC_CFGR_SWS_PLL);

    /* Update the global variable used by delay_us() and BRR calculations */
    SystemCoreClock = 80000000UL;
}

/* ---------------------------------------------------------------------- */
void DWT_Init(void)
{
    /* CoreDebug->DEMCR: enable trace (required before any DWT register
     * is accessible — if TRCENA = 0 all DWT reads return 0)             */
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    __DSB();

    DWT->CYCCNT = 0UL;
    DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;  /* start cycle counter       */
}

/* ---------------------------------------------------------------------- */
/**
 * delay_us — spin-wait for exactly `us` microseconds.
 *
 * Implementation:
 *   cycles_per_us = SystemCoreClock / 1 000 000   (= 80 at 80 MHz)
 *   target_ticks  = us * cycles_per_us
 *
 * The subtraction (DWT->CYCCNT - start) uses unsigned 32-bit arithmetic,
 * so it is correct even when CYCCNT wraps around 0xFFFFFFFF → 0.
 */
void delay_us(uint32_t us)
{
    uint32_t start  = DWT->CYCCNT;
    uint32_t ticks  = us * (SystemCoreClock / 1000000UL);
    while ((DWT->CYCCNT - start) < ticks);
}

void delay_ms(uint32_t ms)
{
    for (uint32_t i = 0; i < ms; i++) {
        delay_us(1000U);
    }
}

/**
 * dht11.c — DHT11 1-wire driver
 *
 * Protocol summary (DHT11 datasheet §5):
 *
 *   [HOST → SENSOR]  Start: pull bus LOW ≥ 18 ms, then release (bus floats
 *                    HIGH via pull-up), wait 20–40 µs.
 *
 *   [SENSOR → HOST]  Response: 80 µs LOW, then 80 µs HIGH.
 *
 *   [SENSOR → HOST]  40 data bits, MSB first:
 *     Each bit starts with ~50 µs LOW, then:
 *       "0" → 26–28 µs HIGH
 *       "1" → 70 µs HIGH
 *
 *   Bit decoding: sample at t = 40 µs after the rising edge.
 *     If still HIGH  → bit = 1  (only "1" bits are still HIGH at 40 µs)
 *     If already LOW → bit = 0  (a "0" bit lasts only 26–28 µs)
 *
 *   Payload (40 bits = 5 bytes):
 *     byte[0] = humidity integer
 *     byte[1] = humidity decimal  (always 0 for DHT11)
 *     byte[2] = temperature integer
 *     byte[3] = temperature decimal (always 0 for DHT11)
 *     byte[4] = checksum = (byte[0]+byte[1]+byte[2]+byte[3]) & 0xFF
 *
 * Data pin: PA1
 *   Output mode: push-pull, no pull  (we drive the bus)
 *   Input mode : floating + internal pull-up (~40 kΩ) as fallback;
 *                use external 4.7 kΩ for reliable results.
 */

#include "stm32l4xx.h"
#include "dht11.h"
#include "clock.h"

#define DHT11_PORT  GPIOA
#define DHT11_PIN   1U      /* PA1 */

/* ---------------------------------------------------------------------- */
/* Internal helpers                                                         */
/* ---------------------------------------------------------------------- */

static void pin_output(void)
{
    /* MODER: 01 = General purpose output */
    DHT11_PORT->MODER = (DHT11_PORT->MODER & ~GPIO_MODER_MODE1_Msk)
                      | (1UL << GPIO_MODER_MODE1_Pos);
    DHT11_PORT->OTYPER  &= ~(1UL << DHT11_PIN);   /* push-pull  */
    DHT11_PORT->PUPDR    = (DHT11_PORT->PUPDR & ~GPIO_PUPDR_PUPD1_Msk);
                                                    /* no pull    */
}

static void pin_input(void)
{
    /* MODER: 00 = Input */
    DHT11_PORT->MODER &= ~GPIO_MODER_MODE1_Msk;
    /* Enable internal pull-up (PUPDR: 01) as a fallback for the bus */
    DHT11_PORT->PUPDR = (DHT11_PORT->PUPDR & ~GPIO_PUPDR_PUPD1_Msk)
                      | (1UL << GPIO_PUPDR_PUPD1_Pos);
}

static inline uint8_t pin_read(void)
{
    return (uint8_t)((DHT11_PORT->IDR >> DHT11_PIN) & 1U);
}

/**
 * wait_level — block until the pin reaches `level` or timeout expires.
 *
 * Returns 1 on success, 0 on timeout.
 * timeout_us should be generous enough for the expected pulse width plus
 * some margin; the sensor's maximum response delay is ~80 µs per phase.
 */
static int wait_level(uint8_t level, uint32_t timeout_us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t limit = timeout_us * (SystemCoreClock / 1000000UL);
    while (pin_read() != level) {
        if ((DWT->CYCCNT - start) >= limit) {
            return 0;   /* timeout */
        }
    }
    return 1;
}

/* ---------------------------------------------------------------------- */
/* Public API                                                               */
/* ---------------------------------------------------------------------- */

void DHT11_Init(void)
{
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
    __DSB();

    pin_output();
    /* Drive bus HIGH — idle state.  DHT11 needs ≥1 s power-up time      */
    DHT11_PORT->BSRR = (1UL << DHT11_PIN);
}

DHT11_Status DHT11_Read(DHT11_Data *data)
{
    uint8_t bytes[5] = {0};

    /* ------------------------------------------------------------------ */
    /* 1. Start signal: hold LOW ≥ 18 ms                                  */
    /* ------------------------------------------------------------------ */
    pin_output();
    DHT11_PORT->BRR  = (1UL << DHT11_PIN);   /* pull bus LOW  */
    delay_ms(20);                              /* 20 ms > 18 ms */
    DHT11_PORT->BSRR = (1UL << DHT11_PIN);   /* release HIGH  */
    delay_us(10);                              /* brief drive-HIGH */

    /* ------------------------------------------------------------------ */
    /* 2. Switch to input and wait for DHT11 to respond                   */
    /* ------------------------------------------------------------------ */
    pin_input();

    /* DHT11 first pulls LOW (~80 µs).  We wait for that falling edge.    */
    if (!wait_level(0, 100U)) return DHT11_ERROR_TIMEOUT;

    /* DHT11 then pulls HIGH (~80 µs).  Wait for rising edge.             */
    if (!wait_level(1, 100U)) return DHT11_ERROR_TIMEOUT;

    /* Wait for end of that HIGH pulse (falling edge → data begins).      */
    if (!wait_level(0, 100U)) return DHT11_ERROR_TIMEOUT;

    /* ------------------------------------------------------------------ */
    /* 3. Read 40 data bits                                                */
    /* ------------------------------------------------------------------ */
    for (int i = 0; i < 40; i++) {
        /*
         * Each bit starts with ~50 µs LOW.
         * Wait for the rising edge that signals the start of the data HIGH.
         */
        if (!wait_level(1, 100U)) return DHT11_ERROR_TIMEOUT;

        /*
         * Sample 40 µs into the HIGH period.
         *   "0" bit: HIGH for 26–28 µs → already LOW at t = 40 µs
         *   "1" bit: HIGH for 70 µs    → still HIGH at t = 40 µs
         */
        delay_us(40U);

        bytes[i >> 3] <<= 1;                /* shift byte left          */
        if (pin_read()) {
            bytes[i >> 3] |= 0x01U;         /* set LSB if pin is HIGH   */
        }

        /* Wait for the HIGH to end before the next bit's LOW preamble.  */
        if (!wait_level(0, 100U)) return DHT11_ERROR_TIMEOUT;
    }

    /* ------------------------------------------------------------------ */
    /* 4. Return bus to idle                                               */
    /* ------------------------------------------------------------------ */
    pin_output();
    DHT11_PORT->BSRR = (1UL << DHT11_PIN);

    /* ------------------------------------------------------------------ */
    /* 5. Verify checksum                                                  */
    /* ------------------------------------------------------------------ */
    uint8_t sum = bytes[0] + bytes[1] + bytes[2] + bytes[3];
    if (sum != bytes[4]) return DHT11_ERROR_CHECKSUM;

    data->humidity_int = bytes[0];
    data->humidity_dec = bytes[1];
    data->temp_int     = bytes[2];
    data->temp_dec     = bytes[3];
    data->checksum     = bytes[4];

    return DHT11_OK;
}
